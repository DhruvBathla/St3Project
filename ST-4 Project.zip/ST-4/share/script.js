var x1 = 0;
var x2 = 0;
var x3 = 0;
var x4 = 0;
var x5 = 0;
var x6 = 0;
var x7 = 0;
var x8 = 0;
var x9 = 0;
var x10 = 0;

var current = 1;
var attempted = 0;

function prev() {
  if (current > 1) {
    current--;
  }
  changes(current);
}
function next() {
  if (current < 10) {
    current++;
  }
  changes(current);
}

function submit(data) {
  if (x1 == 0 && data == 1) {
    x1++;
    changes(data);
    attempted++;
  }
  if (x2 == 0 && data == 2) {
    x2++;
    changes(data);
    attempted++;
  }
  if (x3 == 0 && data == 3) {
    x3++;
    changes(data);
    attempted++;
  }
  if (x4 == 0 && data == 4) {
    x4++;
    changes(data);
    attempted++;
  }
  if (x5 == 0 && data == 5) {
    x5++;
    changes(data);
    attempted++;
  }
  if (x6 == 0 && data == 6) {
    x6++;
    changes(data);
    attempted++;
  }
  if (x7 == 0 && data == 7) {
    x7++;
    changes(data);
    attempted++;
  }
  if (x8 == 0 && data == 8) {
    x8++;
    changes(data);
    attempted++;
  }
  if (x9 == 0 && data == 9) {
    x9++;
    changes(data);
    attempted++;
  }
  if (x10 == 0 && data == 10) {
    x10++;
    changes(data);
    attempted++;
  }
  next();
}

const lowerhead = document.querySelector(".lowerhead");
const button = lowerhead.querySelectorAll("button");

function changes(data) {
  button.forEach((ele) => {
    ele.style.background = "grey";
  });
  switch (data) {
    case 1:
      current = 1;
      if (x1 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qnum"><h1>QUESTION ' +
          current +
          '</h1></div><p class="taskques">Grand Central Terminal, Park Avenue, New York is the world</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">largest railway station</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">highest railway station</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">longest railway station</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">None of the above </Label><br><br><button id="submit" onclick="submit(1)" class="submit">SUBMIT</button>';
        console.log("question 1");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qnum"><h1>QUESTION ' +
          current +
          '</h1></div><p class="taskques"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 2:
      current = 2;
      if (x2 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">Garampani sanctuary is located at</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">Junagarh, Gujarat</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">Diphu, Assam</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">Kohima, Nagaland</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">Gangtok, Sikkim</Label><br><br><button id="submit" onclick="submit(2)">SUBMIT</button>';
        console.log("question 2");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 3:
      current = 3;
      if (x3 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">What is 1+2+(3*0)</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">3</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">5</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">0</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">6</Label><br><br><button id="submit" onclick="submit(3)">SUBMIT</button>';
        console.log("question 3");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 4:
      current = 4;
      if (x4 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">Who is the father of Geometry?</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">Aristotle</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">Euclid</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">Pythagoras</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">Kepler</Label><br><br><button id="submit" onclick="submit(4)">SUBMIT</button>';
        console.log("question 4");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 5:
      current = 5;
      if (x5 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">Tripitakas are sacred books of</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">Buddhists</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">Hindus</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">Jains</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">None of these</Label><br><br><button id="submit" onclick="submit(5)">SUBMIT</button>';
        console.log("question 5");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 6:
      current = 6;
      if (x6 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">The Battle of Plassey was fought in</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">1757</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">1782</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">1748</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">1764</Label><br><br><button id="submit" onclick="submit(6)">SUBMIT</button>';
        console.log("question 6");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 7:
      current = 7;
      if (x7 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">When is the World Population Day observed?</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">May 31</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">October 4</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">December 10</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">July 11</Label><br><br><button id="submit" onclick="submit(7)">SUBMIT</button>';
        console.log("question 7");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 8:
      current = 8;
      if (x8 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">20th August is celebrated as</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">Earth Day</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">Sadbhavana Divas</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">No Tobacco Day</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">None of these</Label><br><br><button id="submit" onclick="submit(8)">SUBMIT</button>';
        console.log("question 8");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 9:
      current = 9;
      if (x9 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">Jude Felix is a famous Indian player in which of the fields?</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">Volleyball</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">Tennis</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">Football</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">Hockey</Label><br><br><button id="submit" onclick="submit(9)">SUBMIT</button>';
        console.log("question 9");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
    case 10:
      current = 10;
      if (x10 == 0) {
        document.getElementById("i" + data).style.backgroundColor = "green";
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task">Who was known as Iron man of India?</p>';
        document.getElementById("change2").innerHTML =
          '<input type="radio" id="o1" name="option"><Label class="o11">Govind Ballabh Pant</Label><br><br><input type="radio" id="o2" name="option"><Label class="o22">Jawaharlal Nehru</Label><br><br><input type="radio" id="o3" name="option"><Label class="o33">Subhash Chandra Bose</Label><br><br><input type="radio" id="o4" name="option"><Label class="o44">Sardar Vallabhbhai Patel</Label><br><br><button id="submit" onclick="submit(10)">SUBMIT</button>';
        console.log("question 10");
      } else {
        document.getElementById("change1").innerHTML =
          '<div class="qno"><h1>QUESTION ' +
          current +
          '</h1></div><p class="task"></p>';
        document.getElementById("change2").innerHTML =
          "<h1><b>SUBMITTED</b></h1>";
      }
      break;
  }
  timer();
  let circularProgress = document.querySelector(".circular-progress");
  function timer() {
    timeleft = 0;
    let progressBar = document.getElementById("progressBar");
    downloadTimer = setInterval(function () {
      let x = 30 - timeleft;
      if (timeleft == 31) {
        clearInterval(downloadTimer);
        alert("Oops! Time's Up");
        document.getElementById("panel").classList.add("hide");
        document.getElementById("last_text").classList.remove("hide");
      }
      if (timeleft < 21) {
        progressBar.innerHTML = x;
        circularProgress.style.background = `conic-gradient(#A8E890 ${
          x * 12
        }deg, white ${x * 9.6}deg)`;
      } else {
        circularProgress.style.background = `conic-gradient(red ${
          x * 9.6
        }deg, white ${x * 9.6}deg)`;
        progressBar.innerHTML = "0" + x;
      }
      timeleft += 1;
    }, 1000);
  }
}
