import React from 'react'

export default function Home() {
  return (
    <div>
    <h1 className='home_section'>Hey!You are Wlecome to Worlds's Best Matchmaking service <br></br>Start your relationship by Sign Up Today  </h1>
    </div>
  )
}
